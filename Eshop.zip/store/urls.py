
from django.contrib import admin
from django.urls import path
from .views.home import index
from .views.signup import signup
from .views.login import login , logout
from .views.cart import cart
from .views.checkout import CheckOut
from .views.orders import Orderview

urlpatterns = [
    path('', index.as_view(), name='homepage'),
    

    path('signup', signup.as_view(), name='signup'),
    path('login', login.as_view(), name='login'),
    path('logout', logout , name='logout'),
    path('cart', cart.as_view() , name='cart'),
    path('check-out', CheckOut.as_view() , name='checkout'),
    path('order', Orderview.as_view() , name='order'),
]